<?php

return array(

	'simple' => array(
		'text_transform' => 'none',
		'letter_spacing' => '0px',
		'font_weight' => '600',
	),

	'modern' => array(
		'text_transform' => 'uppercase',
		'letter_spacing' => '2px',
		'font_weight' => '300',
	),


	

);
