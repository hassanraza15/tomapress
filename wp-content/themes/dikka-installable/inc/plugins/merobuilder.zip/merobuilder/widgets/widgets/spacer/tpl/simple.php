<?php if(!empty($instance['padding'])) : ?>
<div style="margin-bottom:<?php echo esc_attr($instance['padding']); ?>px;"></div>
<?php endif;?>