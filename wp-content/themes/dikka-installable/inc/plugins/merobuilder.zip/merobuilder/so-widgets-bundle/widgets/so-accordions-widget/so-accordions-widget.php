<?php
/*
Widget Name: Accordions Widget
Description: Displays block of accordions .
Version: trunk
Author: Sunil chaulagain
Author URI: http://tuchuk.com
*/

return new SiteOrigin_Widgets_Loader( 'accordions', __FILE__, plugin_dir_path(__FILE__).'inc/accordions-widget.php' );