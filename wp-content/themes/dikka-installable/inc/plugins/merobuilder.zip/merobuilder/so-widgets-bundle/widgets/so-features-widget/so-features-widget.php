<?php
/*
Widget Name: Features Widget
Description: Displays a block of features with icons.
Version: trunk
Author: Greg Priday
Author URI: http://siteorigin.com
*/

return new SiteOrigin_Widgets_Loader( 'features', __FILE__, plugin_dir_path(__FILE__).'inc/features-widget.php' );