<?php
/*
Widget Name: Images Widget
Description: Displays a block of images .
Version: trunk
Author: Sunil chaulagain
Author URI: http://tuchuk.com
*/
return new SiteOrigin_Widgets_Loader( 'images', __FILE__, plugin_dir_path(__FILE__).'inc/widget.php' );