<?php
/*
Widget Name: Custom Button Widget
Description: Add a new button block .
Version: trunk
Author: Sunil chaulagain
Author URI: http://tuchuk.com
*/
return new SiteOrigin_Widgets_Loader( 'cbutton', __FILE__, plugin_dir_path(__FILE__).'inc/widget.php' );