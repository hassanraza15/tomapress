<?php
/*
Widget Name: Icons Widget
Description: Displays a block of icons .
Version: trunk
Author: Sunil chaulagain
Author URI: http://tuchuk.com
*/

return new SiteOrigin_Widgets_Loader( 'icons', __FILE__, plugin_dir_path(__FILE__).'inc/icons-widget.php' );