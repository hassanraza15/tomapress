<?php
/*
Widget Name: Services Widget
Description: Displays a block of services with icons.
Version: trunk
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/

return new SiteOrigin_Widgets_Loader( 'services', __FILE__, plugin_dir_path(__FILE__).'inc/services-widget.php' );