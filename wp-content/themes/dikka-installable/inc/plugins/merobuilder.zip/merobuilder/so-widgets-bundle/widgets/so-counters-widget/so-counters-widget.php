<?php
/*
Widget Name: Counters Widget
Description: Displays a block of counters with icons.
Version: trunk
Author: Sunil Chaulagain
Author URI: http://tuchuk.com
*/

return new SiteOrigin_Widgets_Loader( 'counters', __FILE__, plugin_dir_path(__FILE__).'inc/counters-widget.php' );